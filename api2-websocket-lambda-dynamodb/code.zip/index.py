import json

def hello(event, context):
    print("Hi !")
    return "Hello World"